﻿using ConsoleApp1.Control;
using ConsoleApp1.Model;
using ConsoleApp1.Movel;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var contaService = new ContaServo();

            var conta1 = new Conta(1, "João", 1000);
            var conta2 = new Conta(2, "Maria", 500);

            var controller = new TransacaoController(contaService);

            // Depósito
            var deposito = new Depositar(conta1, contaService);
            controller.ExecutarTransacao(deposito, 200);

            // Saque
            var saque = new Sacar(conta1, contaService);
            controller.ExecutarTransacao(saque, 100);

            // Transferência
            var transferencia = new Transferir(conta1, conta2, contaService);
            controller.ExecutarTransacao(transferencia, 250);

            controller.ExecutarTransacao(deposito, 200);

            Console.WriteLine($"\nSaldo final de {conta1.Titular}: {conta1.Saldo:C}");
            Console.WriteLine($"Saldo final de {conta2.Titular}: {conta2.Saldo:C}");

            
        }
    }
}
