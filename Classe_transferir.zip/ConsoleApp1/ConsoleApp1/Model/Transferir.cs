﻿using ConsoleApp1.Control;
using ConsoleApp1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Movel
{
    internal class Transferir : Itransacao
    {
        private readonly Conta _origem;
        private readonly Conta _destino;
        private readonly IContaServo _contaService;
        public DateTime Data { get; private set; }
        public Transferir(Conta origem, Conta destino, IContaServo contaService)
        {
            _origem = origem;
            _destino = destino;
            _contaService = contaService;
        }

        public void Executar(decimal valor)
        {
           _contaService.transferir(_origem,_destino,valor);
            Data = DateTime.Now;

            Console.WriteLine($"Transferência (Pix) de {valor:C} realizada as {Data} concluida com sucesso de {_origem.Titular} para {_destino.Titular}");
        }
    }
}
