﻿using ConsoleApp1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Control
{
    internal interface IContaServo
    {
        void Depositar(Conta conta, decimal valor);
        void Sacar(Conta conta, decimal valor);
        void AtualizarSaldo(Conta conta, decimal novoSaldo);
        void transferir(Conta Origem,Conta Destino ,decimal valor);
    }
}
