﻿using ConsoleApp1.Movel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Control
{
    internal class TransacaoController
    {
        private readonly IContaServo _contaService;
        private readonly List<Itransacao> _historico = new List<Itransacao>();
        public TransacaoController(IContaServo contaService)
        {
            _contaService = contaService;
        }



        public void ExecutarTransacao(Itransacao transacao, decimal valor)
        {
            transacao.Executar(valor);
            _historico.Add(transacao);
        }

        public List<Itransacao> ObterHistorico()
        {
            var historico = _historico;
            foreach (var t in historico)
            {
                Console.WriteLine($"{t.GetType().Name}");
            }
            return _historico;
        }
    }
}

