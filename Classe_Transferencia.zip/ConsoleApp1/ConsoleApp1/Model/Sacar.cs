﻿using ConsoleApp1.Control;
using ConsoleApp1.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace ConsoleApp1.Movel
{
    internal class Sacar : Itransacao
    {
        private readonly Conta _conta;
        private readonly IContaServo _contaService;

        public Sacar(Conta conta, IContaServo contaService)
        {
            _conta = conta;
            _contaService = contaService;
        }

        public void Executar(decimal valor)
        {
            _contaService.Sacar(_conta, valor);
            Console.WriteLine($"Saque de {valor:C} realizado com sucesso da conta de {_conta.Titular}");
        }
    }
}
