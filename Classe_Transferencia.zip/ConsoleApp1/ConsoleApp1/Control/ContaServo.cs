﻿using ConsoleApp1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Control
{
    internal class ContaServo : IContaServo
    {
        public void Depositar(Conta conta, decimal valor)
        {
            if (valor <= 0)
                throw new ArgumentException("O valor do depósito deve ser positivo.");

            conta.AtualizarSaldo(conta.Saldo + valor);
        }

        public void Sacar(Conta conta, decimal valor)
        {
            if (valor <= 0)
                throw new ArgumentException("O valor do saque deve ser positivo.");

            if (conta.Saldo < valor)
                throw new InvalidOperationException("Saldo insuficiente.");

            conta.AtualizarSaldo(conta.Saldo - valor);
        }

        public void AtualizarSaldo(Conta conta, decimal novoSaldo)
        {
            conta.AtualizarSaldo(novoSaldo);
        }
    }
}
