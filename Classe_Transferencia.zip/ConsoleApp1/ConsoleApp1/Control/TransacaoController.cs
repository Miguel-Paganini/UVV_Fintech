﻿using ConsoleApp1.Movel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Control
{
    internal class TransacaoController
    {
        private readonly IContaServo _contaService;

        public TransacaoController(IContaServo contaService)
        {
            _contaService = contaService;
        }

        public void ExecutarTransacao(Itransacao transacao, decimal valor)
        {
            transacao.Executar(valor);
        }
    }
}

